"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
class Client {
    constructor(cognito = new aws_sdk_1.CognitoIdentityServiceProvider({
        apiVersion: "2016-04-18"
    })) {
        this.cognito = cognito;
    }
}
exports.Client = Client;
