"use strict";
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
const axios_1 = require("axios");
const qs = require("qs");
const xml2js_1 = require("xml2js");
class CreditService {
    static xmlToJson(xml) {
        return new Promise((resolve, reject) => {
            xml2js_1.parseString(xml, (error, result) => error ? reject(error) : resolve(result));
        });
    }
    static async enroll(data) {
        try {
            const newMember = await CreditService.callApi(this.baseUrl + '/enroll', Object.assign({}, data, { branding: this.partnerCode }));
            console.log('idCreditServices enroll', newMember);
            return newMember;
        }
        catch (error) {
            throw new Error(`Failed to enroll in IDCreditServices: ${error.message || error}`);
        }
    }
    static async callApi(url, requestData, rawResult) {
        const formData = Object.assign({}, requestData, { partnerCode: this.partnerCode, partnerPass: this.partnerPass });
        const { data } = await axios_1.default.post(url, qs.stringify(formData), {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
        if (rawResult) {
            return data;
        }
        const parsedData = (await this.xmlToJson(data));
        console.debug('[CreditService]: callApi result: ', parsedData);
        const _a = parsedData.Response, { ErrorCode: errorCode, ErrorMessage: errorMessage } = _a, result = __rest(_a, ["ErrorCode", "ErrorMessage"]);
        if (errorMessage || errorCode) {
            console.debug('[CreditService]: Error calling api', errorCode, errorMessage);
            throw new Error(`${errorCode} ${errorMessage}`);
        }
        return result;
    }
}
CreditService.partnerCode = process.env.PARTNER_CODE;
CreditService.partnerPass = process.env.PARTNER_PASS;
CreditService.baseUrl = 'https://api.idandcredit.com/api';
exports.default = CreditService;
