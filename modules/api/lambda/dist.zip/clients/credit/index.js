"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var credit_1 = require("./credit");
exports.CreditServiceClient = credit_1.default;
