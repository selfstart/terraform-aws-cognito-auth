"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _1 = require("../_");
class ManagementClient extends _1.Client {
    async verifyUser(username) {
        await Promise.all([
            this.cognito.adminConfirmSignUp({
                UserPoolId: process.env.COGNITO_USER_POOL_ID,
                Username: username
            }).promise(),
            this.cognito.adminUpdateUserAttributes({
                UserPoolId: process.env.COGNITO_USER_POOL_ID,
                Username: username,
                UserAttributes: [
                    {
                        Name: "email_verified",
                        Value: "true"
                    }
                ]
            }).promise()
        ]);
    }
    async deleteUser(username) {
        await this.cognito.adminDeleteUser({
            UserPoolId: process.env.COGNITO_USER_POOL_ID,
            Username: username
        }).promise();
    }
    async changePassword(username, password) {
        const { Username: id, UserAttributes } = await this.cognito.adminGetUser({
            UserPoolId: process.env.COGNITO_USER_POOL_ID,
            Username: username
        }).promise();
        await this.deleteUser(id);
        await this.cognito.signUp({
            ClientId: process.env.COGNITO_USER_POOL_CLIENT_ID,
            Username: id,
            Password: password,
            UserAttributes: UserAttributes.filter(attr => {
                return ["sub", "email_verified"].indexOf(attr.Name) === -1;
            })
        }).promise();
        await this.verifyUser(id);
    }
}
exports.ManagementClient = ManagementClient;
