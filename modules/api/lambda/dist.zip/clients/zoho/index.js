"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var zoho_1 = require("./zoho");
exports.ZohoClient = zoho_1.default;
