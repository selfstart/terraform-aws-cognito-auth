"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const axios_1 = require("axios");
const FormData = require("form-data");
class ZohoService {
    static async findLead(data) {
        const options = {
            method: "GET",
            url: ZohoService.lead_url + "search",
            headers: {
                Authorization: "Bearer " + ZohoService.access_token,
            },
            params: {
                criteria: data.id
                    ? `id:equals:${data.id}`
                    : `Email:equals:${data.Email}`,
            },
        };
        try {
            const lead = await ZohoService.callApi(options);
            return lead;
        }
        catch (error) {
            throw new Error("Failed search");
        }
    }
    static async attachments(data) {
        const options = {
            method: "GET",
            url: ZohoService.lead_url + data.id + "/Attachments",
            headers: {
                Authorization: "Bearer " + ZohoService.access_token,
            },
        };
        try {
            const { data } = await ZohoService.callApi(options);
            return data.map((attachment) => {
                return {
                    id: attachment.id,
                    fileName: attachment.File_Name,
                    url: attachment["$link_url"],
                };
            });
        }
        catch (error) {
            throw new Error("Failed search");
        }
    }
    static async updateLead(id, data) {
        const options = {
            method: "PUT",
            url: ZohoService.lead_url + id,
            headers: {
                Authorization: "Bearer " + ZohoService.access_token,
            },
            data,
        };
        const { details: { id: newId }, } = await ZohoService.callApi(options);
        return newId;
    }
    static async newLead(data) {
        const options = {
            method: "POST",
            url: ZohoService.lead_url.slice(0, -1),
            headers: {
                Authorization: "Bearer " + ZohoService.access_token,
            },
            data,
        };
        const { details: { id: newId }, } = await ZohoService.callApi(options);
        if (!newId) {
            throw new Error("Failed creating new Zoho lead");
        }
        return newId;
    }
    static async attach(data, url) {
        const formData = new FormData();
        formData.append("attachmentUrl", url + "&created=" + +new Date());
        const formHeaders = formData.getHeaders();
        var options = {
            method: "POST",
            url: ZohoService.lead_url + data.id + "/Attachments",
            headers: Object.assign({}, formHeaders, { Authorization: "Bearer " + ZohoService.access_token }),
            data: formData,
        };
        const { details: { id: newId }, } = await ZohoService.callApi(options);
        return newId;
    }
    static async refreshToken() {
        const options = {
            method: "POST",
            url: "https://accounts.zoho.com/oauth/v2/token",
            params: {
                grant_type: "refresh_token",
                refresh_token: ZohoService.refresh_token,
                client_id: ZohoService.client_id,
                client_secret: ZohoService.client_secret,
            },
        };
        const { data: { access_token }, } = await ZohoService.executeCall(options);
        return access_token;
    }
    static async callApi(options) {
        ZohoService.access_token = await ZohoService.refreshToken();
        const authHeader = "Bearer " + ZohoService.access_token;
        const response = await ZohoService.executeCall(Object.assign({}, options, { headers: Object.assign({}, options.headers, { Authorization: authHeader }) }));
        return deriveZohoResponse(response);
    }
    static async executeCall(options) {
        return axios_1.default(options).catch((error) => {
            console.log('[zoho]: executeCall err ->', error);
            return error;
        });
    }
}
ZohoService.client_id = process.env.ZOHO_ID;
ZohoService.client_secret = process.env.ZOHO_SECRET;
ZohoService.access_token = process.env.ZOHO_TOKEN;
ZohoService.refresh_token = process.env.ZOHO_REFRESH_TOKEN;
ZohoService.lead_url = "https://www.zohoapis.com/crm/v2/Leads/";
const deriveZohoResponse = (response) => {
    if (response && response.data && response.data.data[0]) {
        return response.data.data[0];
    }
    else if (response && response.response && response.response.data && response.response.data.data[0]) {
        return response.response.data.data[0];
    }
    else if (response && response.response && response.response.data[0]) {
        return response.response.data[0];
    }
    else if (response && response.data) {
        return response.data;
    }
    else {
        return response;
    }
};
exports.default = ZohoService;
