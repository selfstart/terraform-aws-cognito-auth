"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const clients_1 = require("../../clients");
const utilities_1 = require("../../utilities");
const _1 = require("../_");
const schema = require("../../common/events/register/index.json");
const credit_1 = require("clients/credit");
exports.post = _1.handler(schema, async ({ body: { email, password, phoneNumber, firstName, lastName } }) => {
    console;
    utilities_1.throwOnPasswordPolicyViolation(password);
    const auth = new clients_1.AuthenticationClient();
    try {
        const zohoId = await clients_1.ZohoClient.newLead({
            data: [
                {
                    Email: email,
                    First_Name: firstName,
                    Last_Name: lastName,
                    Phone: phoneNumber
                }
            ]
        });
        await credit_1.CreditServiceClient.enroll({
            email,
            memberId: zohoId,
            packageId: '739',
            phone: phoneNumber,
            lastname: lastName,
            firstname: firstName
        });
        await auth.register(email, password, zohoId);
        return { body: { success: true, newLeadId: zohoId } };
    }
    catch (e) {
        console.debug('[Registration]: Account registration failed', email, password, phoneNumber, firstName, lastName, e);
        return { body: { success: false, message: e } };
    }
});
