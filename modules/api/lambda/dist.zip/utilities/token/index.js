"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function parseTokenFromHeader(authorization) {
    return (authorization || "").replace(/^Bearer\s+/, "");
}
exports.parseTokenFromHeader = parseTokenFromHeader;
